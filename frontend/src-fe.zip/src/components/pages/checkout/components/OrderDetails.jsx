import { Card, Typography, Row, Col, Image, Space, Divider, Input, Tag } from 'antd';
import { formatPrice } from '../../../../utils/StringFormat';
import { useFlashSales } from '../../../../hooks/useFlashSales';
import './OrderDetails.css';

const { Title, Text } = Typography;

const getProductImageForOrder = (productData, selectedColor) => {
  const product = productData.productDetails || productData.product || productData;

  if (!product) return 'https://via.placeholder.com/150x150?text=No+Image';

  // 1. Ưu tiên tìm ảnh theo MÀU đã chọn
  if (product.colorOptions && Array.isArray(product.colorOptions)) {
    const colorMatch = product.colorOptions.find(opt => opt.color === selectedColor);
    if (colorMatch && colorMatch.images && colorMatch.images.length > 0) {
      return colorMatch.images[0];
    }
  }

  // 2. Nếu không, lấy ảnh đại diện
  if (product.mainImage) {
    return product.mainImage;
  }

  // 3. Fallback
  return 'https://via.placeholder.com/150x150?text=No+Image';
};

export default function OrderDetails({
  products = [],
  notes = '',
  setNotes,
  status,
  paymentStatus,
  isBuyNow = false,
}) {
  const { getProductFlashSale } = useFlashSales();

  console.log('OrderDetails Debug:', {
    products: products?.length || 0,
    isBuyNow,
    productsData: products,
  });

  return (
    <div>
      <Card>
        <Title level={4} className="order-card-title">
          Order Details
        </Title>
        {products.map((product, idx) => {
          console.log(`Processing product ${idx}:`, product);

          // Handle both cart items and buy now items
          let prod, priceRegular, priceDiscount, isDiscount, isFlashSale, flashSalePrice;

          if (isBuyNow && product.productDetails) {
            // Buy now item with productDetails
            console.log('Processing as buy now item');
            prod = {
              _id: product.product,
              name: product.productDetails.name,
              mainImage: product.productDetails.mainImage,
              description: product.productDetails.brand,
              price: product.productDetails.price || {
                regular: product.price,
                isOnSale: false,
                discountPercent: 0,
              },
            };
          } else {
            // Regular cart item
            console.log('Processing as cart item');
            prod = product.product || product;
          }

          // Check for flash sale first
          const flashSaleInfo = getProductFlashSale(prod._id);
          isFlashSale = !!flashSaleInfo;

          if (isFlashSale) {
            // Flash sale has highest priority
            priceRegular = prod.finalPrice || prod.price?.regular || prod.price;
            flashSalePrice = flashSaleInfo.flashPrice;
            priceDiscount = flashSalePrice;
            isDiscount = true;
            console.log('Flash sale applied:', { priceRegular, flashSalePrice });
          } else {
            // Regular sale logic
            isDiscount = prod.price?.isOnSale && prod.price?.discountPercent;
            priceRegular = prod.price?.regular || prod.price;
            priceDiscount = isDiscount
              ? priceRegular * (1 - prod.price.discountPercent / 100)
              : priceRegular;
          }

          console.log('Processed product:', { prod, priceRegular, priceDiscount, isDiscount });

          const imageUrl = getProductImageForOrder(product, product.color);

          return (
            <Row
              gutter={16}
              align="middle"
              key={prod._id || prod.id || idx}
              style={{ marginBottom: 16 }}
            >
              <Col span={8}>
                <Image src={imageUrl} alt={prod.name} preview={false} className="order-image" />
              </Col>
              <Col span={16}>
                <Text strong className="order-product-name">
                  {prod.name}
                </Text>
                <Text type="secondary" className="order-product-description">
                  {prod.description}
                </Text>
                <Text type="secondary" className="order-product-color">
                  {product.color}
                </Text>
                <Space className="order-product-info">
                  <Text strong>Size {product.size}</Text>
                  <Divider type="vertical" />
                  <Text strong>Quantity {product.quantity}</Text>
                </Space>
                <div>
                  {isFlashSale ? (
                    <>
                      <Tag color="red" style={{ marginBottom: 4, fontSize: 12 }}>
                        FLASH SALE
                      </Tag>
                      <br />
                      <Text strong style={{ fontSize: 20, color: '#ff4757', marginRight: 8 }}>
                        {formatPrice(flashSalePrice)}
                      </Text>
                      <Text delete style={{ fontSize: 16, marginLeft: 8 }}>
                        {formatPrice(priceRegular)}
                      </Text>
                    </>
                  ) : isDiscount ? (
                    <>
                      <Text
                        strong
                        style={{ fontSize: 20, color: 'rgb(74, 105, 226)', marginRight: 8 }}
                      >
                        {formatPrice(priceDiscount)}
                      </Text>
                      <Text delete style={{ fontSize: 16, marginLeft: 8 }}>
                        {formatPrice(priceRegular)}
                      </Text>
                    </>
                  ) : (
                    <Text
                      style={{ fontSize: 20, color: 'rgb(74, 105, 226)', marginRight: 8 }}
                      strong
                    >
                      {formatPrice(priceRegular)}
                    </Text>
                  )}
                </div>
              </Col>
            </Row>
          );
        })}
      </Card>
      <Card className="order-notes-card" style={{ marginTop: 32 }}>
        <label
          style={{
            fontWeight: 600,
            fontSize: 32,
            marginBottom: 8,
            display: 'block',
            color: '#222',
            marginTop: 0,
            fontFamily: 'Rubik',
          }}
        >
          Order Notes
        </label>
        <Input.TextArea
          value={notes}
          onChange={e => setNotes && setNotes(e.target.value)}
          placeholder="Add any notes for your order (if any)"
          autoSize={{ minRows: 2, maxRows: 4 }}
          maxLength={300}
          showCount
          style={{
            borderRadius: 10,
            background: '#fafbfc',
            border: '1px solid #d9d9d9',
            boxShadow: '0 2px 8px rgba(74,105,226,0.04)',
            padding: 12,
            fontSize: 15,
            marginTop: 4,
            transition: 'border-color 0.2s',
          }}
          onFocus={e => (e.target.style.borderColor = '#4A69E2')}
          onBlur={e => (e.target.style.borderColor = '#d9d9d9')}
        />
      </Card>
    </div>
  );
}
