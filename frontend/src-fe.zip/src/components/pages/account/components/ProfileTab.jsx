import React, { useState, useEffect } from 'react';
import { Button, Input, Select, DatePicker, Spin, message, Form } from 'antd';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '@/services/axiosInstance';

import {
  EditOutlined,
  UserOutlined,
  MailOutlined,
  PhoneOutlined,
  HomeOutlined,
  ManOutlined,
  CalendarOutlined,
  InfoCircleOutlined,
  CheckCircleOutlined,
  GiftOutlined,
} from '@ant-design/icons';
import '../account.css';
import TabHeader from '../../../common/components/TabHeader';
import { useAuth } from '../../../../contexts/AuthContext';
import dayjs from 'dayjs';
import {
  fetchProvinces,
  fetchWards,
  formatProvinceName,
  formatWardName,
} from '../../../../utils/vietnamProvinceApi';

export default function ProfileTab() {
  const { user, updateProfile } = useAuth();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [avatarFile, setAvatarFile] = useState(null);
  const [profileImageFile, setProfileImageFile] = useState(null);
  const [totalPoints, setTotalPoints] = useState(0);
  const navigate = useNavigate();
  const [provinces, setProvinces] = useState([]);
  const [wards, setWards] = useState([]);
  const [loadingProvinces, setLoadingProvinces] = useState(false);
  const [loadingWards, setLoadingWards] = useState(false);

  useEffect(() => {
    if (user) {
      form.setFieldsValue({
        fullName: user.fullName,
        email: user.email,
        username: user.username,
        phone: user.phone,
        address: user.address,
        gender: user.gender || 'male',
        aboutMe: user.aboutMe,
        dateOfBirth: user.dateOfBirth ? dayjs(user.dateOfBirth) : null,
      });
      fetchTotalPoints();
    }
  }, [user, form]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoadingProvinces(true);
        const data = await fetchProvinces();
        if (mounted) setProvinces(data);
      } catch (e) {
      } finally {
        if (mounted) setLoadingProvinces(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const handleProvinceChange = async value => {
    form.setFieldsValue({
      provinceCode: value,
      wardCode: undefined,
      provinceName: undefined,
      wardName: undefined,
    });
    const province = provinces.find(p => String(p.code) === String(value));
    form.setFieldsValue({ provinceName: formatProvinceName(province) });
    try {
      setLoadingWards(true);
      const wardList = await fetchWards(value);
      setWards(wardList);
    } catch (e) {
      setWards([]);
    } finally {
      setLoadingWards(false);
    }
  };

  const handleWardChange = value => {
    form.setFieldsValue({ wardCode: value });
    const ward = wards.find(w => String(w.code) === String(value));
    form.setFieldsValue({ wardName: formatWardName(ward) });
  };

  const fetchTotalPoints = async () => {
    try {
      const response = await axiosInstance.get(`/reward-points/user/${user._id}/total`);
      if (response.data.success) {
        setTotalPoints(response.data.data.availablePoints);
      }
    } catch (error) {
      console.error('Failed to fetch total points:', error);
    }
  };

  if (!user) {
    return (
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}
      >
        <Spin size="large" />
      </div>
    );
  }

  const handleAvatarChange = async e => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);

      // Create a preview URL for the selected image
      const reader = new FileReader();
      reader.onloadend = () => {
        const previewImg = document.querySelector('.profile-avatar img');
        if (previewImg) {
          previewImg.src = reader.result;
        }
      };
      reader.readAsDataURL(file);

      // Auto-update avatar immediately
      try {
        setLoading(true);
        const formData = new FormData();
        formData.append('avatar', file);

        const updatedUser = await updateProfile(formData);
        console.log('Avatar updated:', updatedUser);

        // Update preview with server response
        if (updatedUser && updatedUser.avatar) {
          const previewImg = document.querySelector('.profile-avatar img');
          if (previewImg) {
            previewImg.src = updatedUser.avatar;
          }
        }

        message.success('Avatar updated successfully');
      } catch (error) {
        console.error('Avatar update error:', error);
        message.error('Failed to update avatar. Please try again.');

        // Revert preview on error
        const previewImg = document.querySelector('.profile-avatar img');
        if (previewImg && user.avatar) {
          previewImg.src = user.avatar;
        }
      } finally {
        setLoading(false);
      }
    }
  };

  const handleProfileImageChange = async e => {
    const file = e.target.files[0];
    if (file) {
      setProfileImageFile(file);

      const reader = new FileReader();
      reader.onloadend = () => {
        const previewImg = document.querySelector('.profile-profileImage img');
        if (previewImg) {
          previewImg.src = reader.result;
        }
      };
      reader.readAsDataURL(file);

      // Auto-update profile image immediately
      try {
        setLoading(true);
        const formData = new FormData();
        formData.append('profileImage', file);

        const updatedUser = await updateProfile(formData);
        console.log('Profile image updated:', updatedUser);

        // Update preview with server response
        if (updatedUser && updatedUser.profileImage) {
          const previewImg = document.querySelector('.profile-profileImage img');
          if (previewImg) {
            previewImg.src = updatedUser.profileImage;
          }
        }

        message.success('Profile image updated successfully');
      } catch (error) {
        console.error('Profile image update error:', error);
        message.error('Failed to update profile image. Please try again.');

        // Revert preview on error
        const previewImg = document.querySelector('.profile-profileImage img');
        if (previewImg && (user.profileImage || user.avatar)) {
          previewImg.src = user.profileImage || user.avatar;
        }
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSubmit = async values => {
    try {
      setLoading(true);
      const formData = new FormData();

      // Thêm các giá trị form vào FormData
      const composedAddress = [values.address, values.wardName, values.provinceName]
        .filter(Boolean)
        .join(', ');
      const finalValues = { ...values, address: composedAddress };
      Object.keys(finalValues).forEach(key => {
        if (finalValues[key] !== undefined && finalValues[key] !== null) {
          if (key === 'dateOfBirth') {
            formData.append(key, finalValues[key].toISOString());
          } else {
            formData.append(key, finalValues[key]);
          }
        }
      });

      // Thêm file avatar nếu có
      if (avatarFile) {
        formData.append('avatar', avatarFile);
        console.log('Adding avatar file:', avatarFile.name);
      }

      // Thêm file profileImage nếu có
      if (profileImageFile) {
        formData.append('profileImage', profileImageFile);
        console.log('Adding profileImage file:', profileImageFile.name);
      }

      // Ghi log FormData để debug
      console.log('Form data entries:');
      for (let pair of formData.entries()) {
        console.log(
          pair[0] +
            ': ' +
            (pair[0] === 'avatar' || pair[0] === 'profileImage' ? 'File object' : pair[1])
        );
      }

      const updatedUser = await updateProfile(formData);
      console.log('Updated user:', updatedUser);

      // Cập nhật preview ảnh ngay lập tức nếu có URL mới
      if (updatedUser && updatedUser.avatar) {
        const previewImg = document.querySelector('.profile-avatar img');
        if (previewImg) {
          previewImg.src = updatedUser.avatar;
        }
      }
      if (updatedUser && updatedUser.profileImage) {
        const previewImg2 = document.querySelector('.profile-profileImage img');
        if (previewImg2) {
          previewImg2.src = updatedUser.profileImage;
        }
      }

      message.success('Profile updated successfully');
    } catch (error) {
      console.error('Update error:', error);
      message.error(error.message || 'Failed to update profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <TabHeader breadcrumb="Profile" />
      <div className="profile-tab-container">
        <div className="profile-header">
          <div className="profile-avatar">
            {loading && avatarFile ? (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '100%',
                  height: '100%',
                  background: '#f5f5f5',
                  borderRadius: '50%',
                }}
              >
                <Spin size="large" />
              </div>
            ) : (
              <img
                src={
                  user.avatar ||
                  'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png'
                }
                alt="avatar"
                onError={e => {
                  console.log('Avatar load error, falling back to default');
                  e.target.src =
                    'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png';
                  return true; // Prevent infinite error loop
                }}
              />
            )}
            <label
              className="change-avatar-btn"
              style={{
                pointerEvents: loading && avatarFile ? 'none' : 'auto',
                opacity: loading && avatarFile ? 0.5 : 1,
              }}
            >
              <EditOutlined />
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                style={{ display: 'none' }}
                disabled={loading && avatarFile}
              />
            </label>
          </div>
          <div className="profile-info">
            <h2>
              {user.fullName}
              <span className="status" style={{ marginLeft: 8 }}>
                <CheckCircleOutlined style={{ marginRight: 4 }} /> Active
              </span>
            </h2>
            <div className="email">
              <MailOutlined /> {user.email}
            </div>
            <div
              className="point"
              onClick={() => navigate('/account/reward-points')}
              style={{
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                padding: '8px 16px',
                background: '#f0f2f5',
                borderRadius: '6px',
                transition: 'background 0.3s',
                ':hover': {
                  background: '#e6e8eb',
                },
              }}
            >
              <GiftOutlined style={{ marginRight: 8, color: '#1890ff' }} />
              Points: {totalPoints}
            </div>
          </div>
        </div>
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          className="profile-sections-form"
          style={{ width: '100%' }}
        >
          <div className="profile-sections-row" style={{ display: 'flex', gap: 32 }}>
            <div className="profile-section" style={{ flex: 1 }}>
              <div className="profile-section-title">Personal Information</div>
              <Form.Item
                name="fullName"
                label={
                  <label>
                    <UserOutlined /> Full Name
                  </label>
                }
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="dateOfBirth"
                label={
                  <label>
                    <CalendarOutlined /> Date of Birth
                  </label>
                }
                rules={[
                  {
                    validator: (_, value) => {
                      if (!value) {
                        return Promise.resolve();
                      }
                      const today = dayjs();
                      const selectedDate = dayjs(value);

                      if (selectedDate.isAfter(today)) {
                        return Promise.reject(new Error('Date of birth cannot be in the future'));
                      }

                      // Check if age is reasonable (not too old, not too young)
                      const age = today.diff(selectedDate, 'year');
                      if (age > 120) {
                        return Promise.reject(new Error('Please enter a valid date of birth'));
                      }
                      if (age < 0) {
                        return Promise.reject(new Error('Date of birth cannot be in the future'));
                      }

                      return Promise.resolve();
                    },
                  },
                ]}
              >
                <DatePicker
                  style={{ width: '100%' }}
                  disabledDate={current => {
                    // Disable future dates
                    return current && current.isAfter(dayjs(), 'day');
                  }}
                  placeholder="Select your date of birth"
                />
              </Form.Item>
              <Form.Item
                name="gender"
                label={
                  <label>
                    <ManOutlined /> Gender
                  </label>
                }
              >
                <Select>
                  <Select.Option value="male">Male</Select.Option>
                  <Select.Option value="female">Female</Select.Option>
                  <Select.Option value="other">Other</Select.Option>
                </Select>
              </Form.Item>
              <Form.Item
                name="aboutMe"
                label={
                  <label>
                    <InfoCircleOutlined /> About Me
                  </label>
                }
              >
                <Input.TextArea rows={2} placeholder="A short introduction about yourself..." />
              </Form.Item>
              <Form.Item
                label={
                  <label>
                    {' '}
                    <UserOutlined />
                    Profile Image
                  </label>
                }
              >
                <div
                  className="profile-profileImage"
                  style={{ display: 'flex', alignItems: 'center', gap: 12 }}
                >
                  {loading && profileImageFile ? (
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: 225,
                        height: 300,
                        background: '#f5f5f5',
                        borderRadius: 8,
                        border: '1px solid #eee',
                      }}
                    >
                      <Spin size="large" />
                    </div>
                  ) : (
                    <img
                      src={
                        user.profileImage ||
                        user.avatar ||
                        'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png'
                      }
                      alt="profile"
                      style={{
                        width: 225,
                        height: 300,
                        objectFit: 'cover',
                        borderRadius: 8,
                        border: '1px solid #eee',
                      }}
                      onError={e => {
                        e.target.src =
                          'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png';
                        return true;
                      }}
                    />
                  )}
                  <label
                    className="change-avatar-btn"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 8,
                      pointerEvents: loading && profileImageFile ? 'none' : 'auto',
                      opacity: loading && profileImageFile ? 0.5 : 1,
                    }}
                  >
                    <EditOutlined />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleProfileImageChange}
                      style={{ display: 'none' }}
                      disabled={loading && profileImageFile}
                    />
                    <span>Change Profile Image</span>
                  </label>
                </div>
              </Form.Item>
            </div>
            <div className="profile-section" style={{ flex: 1 }}>
              <div className="profile-section-title">Account Information</div>
              <Form.Item
                name="email"
                label={
                  <label>
                    <MailOutlined /> Email
                  </label>
                }
              >
                <Input disabled />
              </Form.Item>
              <Form.Item
                name="username"
                label={
                  <label>
                    <UserOutlined /> Username
                  </label>
                }
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="phone"
                label={
                  <label>
                    <PhoneOutlined /> Phone Number
                  </label>
                }
              >
                <Input />
              </Form.Item>
              <Form.Item
                name="address"
                label={
                  <label>
                    <HomeOutlined /> Address
                  </label>
                }
              >
                <Input placeholder="Detailed Address (street, building, etc.)" />
              </Form.Item>
              <div style={{ display: 'flex', gap: 12 }}>
                <Form.Item name="provinceCode" style={{ flex: 1 }}>
                  <Select
                    showSearch
                    placeholder="Select Province/City"
                    loading={loadingProvinces}
                    optionFilterProp="label"
                    onChange={handleProvinceChange}
                    options={provinces.map(p => ({ label: formatProvinceName(p), value: p.code }))}
                  />
                </Form.Item>
                <Form.Item name="wardCode" style={{ flex: 1 }}>
                  <Select
                    showSearch
                    placeholder="Select Ward/Commune"
                    disabled={!form.getFieldValue('provinceCode')}
                    loading={loadingWards}
                    optionFilterProp="label"
                    onChange={handleWardChange}
                    options={wards.map(w => ({ label: formatWardName(w), value: w.code }))}
                  />
                </Form.Item>
              </div>
              <Form.Item name="provinceName" hidden>
                <Input />
              </Form.Item>
              <Form.Item name="wardName" hidden>
                <Input />
              </Form.Item>
              <Form.Item
                label={
                  <label>
                    <CalendarOutlined /> Join Date
                  </label>
                }
              >
                <Input value={new Date(user.createdAt).toLocaleDateString()} disabled />
              </Form.Item>
            </div>
          </div>
        </Form>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <Button
            type="primary"
            className="save-btn"
            loading={loading}
            style={{ minWidth: 180, fontWeight: 600, fontSize: 18 }}
            onClick={() => form.submit()}
          >
            Save Changes
          </Button>
        </div>
      </div>
    </>
  );
}
